using Microsoft.AspNetCore.Authorization;

namespace Airport.Authorization
{
    public class AllowedInLoungeRequirement : IAuthorizationRequirement { }
}