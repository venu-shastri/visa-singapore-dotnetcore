﻿namespace ToDoList
{
    public class ToDoModel
    {
        public int Number { get; set; }
        public string Title { get; set; }
        public string Login { get; set; }
        public string State { get; set; }
    }
}
