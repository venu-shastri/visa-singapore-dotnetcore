﻿namespace DependencyInjectionExample.Services
{
    public interface IMessageSender
    {
        void SendMessage(string message);
    }
}
