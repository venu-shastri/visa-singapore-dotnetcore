﻿namespace LifetimeExamples
{
    public class RowCountViewModel
    {
        public int DataContextCount { get; set; }
        public int RepositoryCount { get; set; }
    }
}
