﻿namespace DependencyInjectionExample.Services
{
    public interface IEmailSender
    {
        void SendEmail(string username);
    }
}
