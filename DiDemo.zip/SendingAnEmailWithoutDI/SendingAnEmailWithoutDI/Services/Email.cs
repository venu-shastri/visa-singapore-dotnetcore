﻿namespace DependencyInjectionExample.Services
{
    public class Email
    {
        public string Address { get; set; }
        public string Message { get; set; }
    }
}
