﻿namespace StoreViewerApplication
{
    public class Location
    {
        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }
    }
}
