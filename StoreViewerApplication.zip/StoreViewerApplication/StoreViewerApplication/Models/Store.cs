﻿namespace StoreViewerApplication
{
    public class Store
    {
        public string Name { get; set; }
        public Location Location { get; set; }
    }
}